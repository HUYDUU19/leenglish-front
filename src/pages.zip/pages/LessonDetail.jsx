import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import {
  Typography,
  Box,
  Divider,
  List,
  ListItem,
  ListItemText,
} from "@mui/material";
import { Link as RouterLink } from "react-router-dom";

const LessonDetail = () => {
  const { lessonId } = useParams();
  const [lesson, setLesson] = useState(null);
  const [exercises, setExercises] = useState([]);

  useEffect(() => {
    axios
      .get(`http://localhost:8080/api/lessons/${lessonId}`)
      .then((res) => setLesson(res.data))
      .catch((err) => console.error(err));

    axios
      .get(`http://localhost:8080/api/exercises/lesson/${lessonId}`)
      .then((res) => setExercises(res.data))
      .catch((err) => console.error(err));
  }, [lessonId]);

  if (!lesson) return <Typography>Loading lesson...</Typography>;

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        {lesson.title}
      </Typography>
      <Typography variant="subtitle1" gutterBottom color="text.secondary">
        {lesson.description}
      </Typography>
      <Divider sx={{ my: 2 }} />
      <Typography variant="body1" gutterBottom>
        {lesson.content}
      </Typography>

      <Divider sx={{ my: 4 }} />
      <Typography variant="h5">Exercises</Typography>
      <List>
        {exercises.map((ex) => (
           <ListItem key={ex.id}>
           <ListItemText primary={ex.title} secondary={ex.description} />
         </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default LessonDetail;
