import { Typography } from '@mui/material';
import axios from 'axios';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { List, ListItem, ListItemText } from '@mui/material';

const ExerciseList = () => {
    const {exerciseId} = useParams();
    const [exercises, setExercises] = useState([]);
    
    useEffect(() => {
        axios.get(`http://localhost:8080/api/exercises/exercise/${exerciseId}`)
        .then(res => setExercises(res.data))
        .catch(err => console.error(err));
        }, [exerciseId]);

    
    return (<>
    <Typography variant="h5">Exercises for Lesson ID: {exerciseId}</Typography>
    <List>
        {exercises.map(exercise => (
            <ListItem button component={Link} to={`/exercise/${exercise.id}`} key={exercise.id}>
                <ListItemText primary={exercise.title} secondary={exercise.description} />
            </ListItem>
        ))}
    </List>
    </>

    );

}

export default ExerciseList;