import React from 'react';
import { Button, Grid, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const levels = ['Beginner', 'Intermediate', 'Advanced'];

const LessonSelection = () => {
  const navigate = useNavigate();

  return (
    <Grid container spacing={3} justifyContent="center" padding={4}>
      <Typography variant="h4" gutterBottom align="center">
        Select a Level
      </Typography>

      {levels.map((level) => (
        <Grid item key={level}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => navigate(`/lessons/${level.toLowerCase()}`)}
          >
            {level}
          </Button>
        </Grid>
      ))}
    </Grid>
  );
};

export default LessonSelection;
