
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import{Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Typography
,List,ListItem,ListItemText }  from '@mui/material';
import { Link,useParams } from 'react-router-dom';

const LessonList = () => {
  const { level } = useParams();
  const [lessons, setLessons] = useState([]);

  useEffect(() => {
    axios.get(`http://localhost:8080/api/lesson/level/${level}`)
      .then(res => setLessons(res.data))
      .catch(err => console.error(err));
  }, [level]);

  return (
    <>
      <Typography variant="h5">Lessons for Level: {level}</Typography>
      <List>
        {lessons.map(lesson => (
          <ListItem button={true} component={Link} to={`/lesson/${lesson.id}`} key={lesson.id}>
            <ListItemText primary={lesson.title} secondary={lesson.description} />
          </ListItem>
          
        ))}
      </List>

    </>
  );
};

  

export default LessonList;