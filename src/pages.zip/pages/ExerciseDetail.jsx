import React, { use, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Typography,
  RadioGroup,
  FormControlLabel,
  Radio,
  Button,
  Divider,
  Card,
  CardContent,
  CardMedia,
} from "@mui/material";

const ExerciseDetail = () => {
  const { lessonId, exerciseId } = useParams();
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [started, setStarted] = useState(false);
  const [exercise, setExercise] = useState([]);
  const navigate = useNavigate();
  const [Loading, setLoading] = useState(true);
  const [lesson, setLesson] = useState(null);
  useEffect(() => {
    axios
      .get(
        `http://localhost:8080/api/exercise-questions/exercise/${exerciseId}`
      )
      .then((res) => setQuestions(res.data))
      .catch((err) => console.error(err));
  }, [exerciseId]);

  const handleChange = (questionId, value) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };
  useEffect(() => {
    let cancelled = false;
    axios
      .get(
        `http://localhost:8080/api/exercise-questions/exercise/${exerciseId}`
      )
      .then((res) => {
        if (!cancelled) setQuestions(res.data);
      })
      .catch((err) => console.error(err));
    return () => {
      cancelled = true;
    };
  }, [exerciseId]);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      axios.get(`http://localhost:8080/api/lessons/${lessonId}`),
      axios.get(`http://localhost:8080/api/exercise/lessons/${lessonId}`),
    ])
      .then(([lessonRes, exerciseRes]) => {
        setLesson(lessonRes.data);
        setExercise(exerciseRes.data);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, [lessonId]);

  const handleSubmit = () => {
    let correct = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) correct++;
    });
    setScore(correct);
    setSubmitted(true);
  };
  const handleRetry = () => {
    setAnswers({});
    setSubmitted(false);
    setScore(0);
    setStarted(false);
  };

  return (
    <Box p={3}>
      {!started && !submitted && questions.length > 0 && (
        <Box textAlign="center" my={4}>
          <Typography variant="h6">Bạn đã sẵn sàng làm bài chưa?</Typography>
          <Button
            variant="contained"
            color="primary"
            onClick={() => setStarted(true)}
            sx={{ mt: 2 }}
          >
            Bắt đầu
          </Button>
        </Box>
      )}
      {questions.length === 0 && (
        <Box textAlign="center" my={5}>
          <Typography variant="h5" color="error" gutterBottom>
            Hiện tại chưa có bài tập!
          </Typography>
          <Typography variant="body1" gutterBottom>
            Vui lòng chọn một mục khác hoặc quay lại bài học.
          </Typography>
          <Button
            variant="outlined"
            color="primary"
            onClick={() => navigate(`/lessons/${lessonId}`)}
            sx={{ mt: 2 }}
          >
            Quay lại bài học
          </Button>
        </Box>
      )}

      {started &&
        questions.map((q, index) => {
          const options = q.options ? JSON.parse(q.options) : [];
          const userAnswer = answers[q.id];
          const isCorrect = submitted && userAnswer === q.correctAnswer;
          return (
            <Card key={q.id} sx={{ mb: 4 }}>
              <CardContent>
                <Typography variant="h6">
                  Câu {index + 1}: {q.questionText}
                </Typography>

                {q.imageUrl && (
                  <CardMedia
                    component="img"
                    height="200"
                    image={q.imageUrl}
                    alt={`image for question ${index + 1}`}
                    sx={{ my: 2, borderRadius: 1 }}
                  />
                )}

                <RadioGroup
                  value={answers[q.id] || ""}
                  onChange={(e) => handleChange(q.id, e.target.value)}
                >
                  {options.map((opt, i) => (
                    <FormControlLabel
                      key={i}
                      value={opt}
                      control={<Radio />}
                      label={opt}
                      sx={{
                        color:
                          submitted && opt === q.correctAnswer
                            ? "green"
                            : submitted &&
                              opt === userAnswer &&
                              opt !== q.correctAnswer
                            ? "red"
                            : "inherit",
                      }}
                    />
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>
          );
        })}

      {started && !submitted && (
        <Button variant="contained" color="success" onClick={handleSubmit}>
          Nộp bài
        </Button>
      )}

      {submitted && (
        <Box textAlign="center" mt={4}>
          <Typography variant="h5" color="success.main">
            ✅ Bạn đã đúng {score} / {questions.length} câu (
            {((score / questions.length) * 100).toFixed(0)}%)
            <Button
              variant="outlined"
              color="primary"
              onClick={() => navigate(`/lessons/${lessonId}`)}
              sx={{ mt: 2 }}
            >
              Quay lại bài học
            </Button>
            <Button
              variant="outlined"
              color="secondary"
              onClick={handleRetry}
              sx={{ mt: 2, ml: 2 }}
            >
              Làm lại bài
            </Button>
          </Typography>
        </Box>
      )}
    </Box>
  );
};

export default ExerciseDetail;
